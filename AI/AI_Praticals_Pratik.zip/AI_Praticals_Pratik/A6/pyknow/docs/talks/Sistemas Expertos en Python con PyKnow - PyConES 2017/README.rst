Sistemas Expertos en Python con PyKnow
======================================

* Speaker: Roberto Abdelkader Martínez Pérez
* Year: 2017
* Event: PyConES
* Language: Spanish
* PyKnow Version: 1.2.0-alpha
* `Slides <slides.pdf>`_
* `Source <Descuentos.ipynb>`_
* `Video <https://youtu.be/T7QzdVxRaOo>`_
